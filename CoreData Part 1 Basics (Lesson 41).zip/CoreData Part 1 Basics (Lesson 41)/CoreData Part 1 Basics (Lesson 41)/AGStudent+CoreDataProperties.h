//
//  AGStudent+CoreDataProperties.h
//  CoreData Part 1 Basics (Lesson 41)
//
//  Created by Anton Gorlov on 04.08.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "AGStudent.h"

NS_ASSUME_NONNULL_BEGIN

@interface AGStudent (CoreDataProperties)

@property (nullable, nonatomic, retain) NSDate *dateOfBirht;
@property (nullable, nonatomic, retain) NSString *firstName;
@property (nullable, nonatomic, retain) NSString *lastName;
@property (nullable, nonatomic, retain) NSNumber *score;

@end

NS_ASSUME_NONNULL_END
