//
//  AGStudent.m
//  CoreData Part 1 Basics (Lesson 41)
//
//  Created by Anton Gorlov on 04.08.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGStudent.h"

@implementation AGStudent

// Insert code here to add functionality to your managed object subclass

@end
