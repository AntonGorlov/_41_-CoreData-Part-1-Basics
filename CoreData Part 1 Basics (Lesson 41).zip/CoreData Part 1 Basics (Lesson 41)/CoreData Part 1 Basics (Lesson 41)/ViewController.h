//
//  ViewController.h
//  CoreData Part 1 Basics (Lesson 41)
//
//  Created by Anton Gorlov on 02.08.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

