//
//  AGStudent+CoreDataProperties.m
//  CoreData Part 1 Basics (Lesson 41)
//
//  Created by Anton Gorlov on 04.08.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "AGStudent+CoreDataProperties.h"

@implementation AGStudent (CoreDataProperties)

@dynamic dateOfBirht;
@dynamic firstName;
@dynamic lastName;
@dynamic score;


//перепишем Property студента ,переопределим геттер и сеттер.

//@dynamic не генерирует iVar!!!!

- (void) setFirstName:(NSString *)firstName { //переопределим сеттер

    [self willChangeValueForKey:@"firstName"];
    [self setPrimitiveValue:firstName forKey:@"firstName"];
    [self didChangeValueForKey:@"firstName"];

    NSLog(@"SET FIRST NAME!!!!");
}


- (NSString*) firstName { //переопределим геттер

    NSString *string = nil;
    [self willAccessValueForKey:@"firstName"]; //есть еще и такой метод предупреждения Observer (получаем доступ к этой Value)
    string = [self primitiveValueForKey:@"firstName"];
    [self didAccessValueForKey:@"firstName"];
    
    NSLog(@"GET FIRST NAME!!!!");
    
    return string;
}


//можно ли в property записать такое значение
//валидация отрабатывает ,когда сохраняем в Context
/*
- (BOOL) validateLastName:(id  _Nullable __autoreleasing *)value error:(NSError * _Nullable __autoreleasing *)error {

    *error = [NSError errorWithDomain:@"Bad Last Name" code:123 userInfo:nil];
    return NO;
}
 */
@end
